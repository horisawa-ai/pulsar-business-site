#!/usr/bin/env python3
"""Monta a folha HTML da skill Gemini a partir de um JSON e confere as regras.

Uso: python3 scripts/montar_html.py dados.json saida.html

Formato do JSON (ver exemplos/hernia-inguinal.json):
{
  "titulo": "...",
  "narracao": "texto corrido, um paragrafo so",
  "legenda": "titulo\\n\\nparagrafo\\n\\n#a #b #c",
  "flow": false,
  "cenas": [{"fala": "...", "imagem": "...", "animar": "...", "direto": "..."}],
  "refs": [{"texto": "...", "pmid": "...", "url": ""}]
}
O script calcula sozinho os segundos de fala de cada cena (palavras / 2,5,
arredondado pra cima), a duracao do clipe (10 s, ou 8 s com "flow": true)
e a linha de resumo do topo. Se alguma regra falhar, ele para e mostra o erro.
"""
import json, math, os, re, sys

NEG = [" no ", " not ", "nothing", "never", "avoid", "without"]
DASH = [chr(0x2014), chr(0x2013)]

def falha(msg):
    sys.exit("ERRO: " + msg)

def main():
    if len(sys.argv) != 3:
        falha("uso: montar_html.py dados.json saida.html")
    d = json.load(open(sys.argv[1], encoding="utf-8"))
    seg = 8 if d.get("flow") else 10
    limite = 20 if d.get("flow") else 25
    cenas = d["cenas"]
    if not 3 <= len(cenas) <= 8:
        falha("o video precisa ter de 3 a 8 cenas")
    total = 0
    for i, c in enumerate(cenas, 1):
        n = len(c["fala"].split())
        if n > limite:
            falha("cena %d tem %d palavras de fala (maximo %d)" % (i, n, limite))
        c["fs"] = math.ceil(n / 2.5)
        c["seg"] = seg
        total += c["fs"]
        for k in ("imagem", "animar", "direto"):
            p = c[k]
            if "\n" in p:
                falha("cena %d, prompt %s tem quebra de linha" % (i, k))
            low = " " + p.lower() + " "
            ruins = [w.strip() for w in NEG if w in low]
            if ruins:
                falha("cena %d, prompt %s tem negacao: %s" % (i, k, ruins))
        if not c["animar"].startswith("Animate this image."):
            falha("cena %d: o prompt de animar tem que abrir com 'Animate this image.'" % i)
        if not c["imagem"].startswith("Generate a vertical 9:16 portrait image."):
            falha("cena %d: o prompt de imagem tem que abrir com 'Generate a vertical 9:16 portrait image.'" % i)
        marcas = re.findall(r"\d+ to \d+ s:", c["direto"])
        if len(marcas) != (4 if d.get("flow") else 5):
            falha("cena %d: a marcha do video direto tem %d trechos" % (i, len(marcas)))
    if total < 30:
        falha("a narracao tem %d s de fala; o minimo e 30 s" % total)
    if "\n" in d["narracao"].strip():
        falha("a narracao completa tem que ser um paragrafo so")
    leg = d["legenda"]
    if len(leg) > 400:
        falha("a legenda tem %d caracteres (maximo 400)" % len(leg))
    tags = re.findall(r"#\w+", leg)
    if len(tags) != 3:
        falha("a legenda tem %d hashtags (tem que ser exatamente 3)" % len(tags))
    tudo = json.dumps(d, ensure_ascii=False)
    for x in DASH:
        if x in tudo:
            falha("tem travessao no conteudo")
    d["sub"] = "%d cenas · %d segundos de fala · Gemini/Flow" % (len(cenas), total)
    reel = {k: d[k] for k in ("titulo", "sub", "narracao", "legenda", "cenas", "refs")}
    base = os.path.dirname(os.path.abspath(__file__))
    tpl = open(os.path.join(base, "..", "assets", "template.html"), encoding="utf-8").read()
    i = tpl.index("const REEL = ")
    j = tpl.index(";\n", i) + 1
    js = "const REEL = " + json.dumps(reel, ensure_ascii=False).replace("</", "<\\/") + ";"
    html = tpl[:i] + js + tpl[j:]
    html = html.replace("<title>Reel</title>", "<title>%s</title>" % d["titulo"])
    open(sys.argv[2], "w", encoding="utf-8").write(html)
    print("ok: %d cenas, %d s de fala, %s" % (len(cenas), total, sys.argv[2]))

main()
