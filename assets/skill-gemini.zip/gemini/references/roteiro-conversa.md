# Roteiro da conversa, com exemplo real

Como a skill conversa em cada etapa, usando o exemplo da hérnia inguinal do começo ao fim. Serve de régua de tom, de tamanho e de ordem. As mensagens abaixo são modelo de forma; o conteúdo muda com o tema.

## 0 · Abertura

Quando a pessoa chama a skill sem tema:

> Bora criar um vídeo curto pra Reels, TikTok ou Shorts! 🎬
>
> No final você recebe um arquivo com tudo pronto: é só copiar, colar no Gemini e gerar.
>
> Funciona com qualquer tema, de corpo humano e remédio até engenharia, natureza e tecnologia. Mas onde ela brilha MESMO é em remédio, medicina, fisiologia e corpo humano: é ali que os vídeos ficam absurdos.
>
> Funciona assim: primeiro a gente escolhe o tema, depois escreve o texto que vai ser falado no vídeo, depois monta as cenas, e aí sai o arquivo.
>
> Qual vai ser o tema do teu vídeo?

Quando a pessoa já manda o tema junto ("usando a skill gemini, faz um vídeo sobre hérnia inguinal"), a abertura cabe em 2 linhas e a etapa 1 vem na mesma resposta.

## 1 · Bater o tema

Pesquisar ANTES de responder. Depois, no máximo isto:

> **O que a ciência diz, em resumo:** [3 ou 4 linhas simples, com a fonte citada]
>
> **3 jeitos de contar essa história:**
> 1. **"Você já nasceu com o buraco da hérnia."** A virilha tem um túnel natural, o canal inguinal. Nos homens, é por ele que o testículo desceu antes do nascimento. A hérnia é o que vem de dentro da barriga entrando nesse túnel.
> 2. **"O caroço que some quando você deita."** [uma linha]
> 3. **"Nem toda hérnia precisa de cirurgia correndo, mas tem uma que precisa."** [uma linha]
>
> Eu iria na **1**: ela muda o jeito que a pessoa entende a hérnia.
>
> **Tamanho:** 4 cenas, uns 35 segundos de fala.
>
> Qual dessas você quer?

O melhor ângulo é sempre o que reorganiza o tema na cabeça de quem assiste (o "não é X, é Y").

## 2 · Fechar a narração

> Fechou, vai ser a 1. Aqui está o texto que você vai falar no vídeo. Ficou em 5 cenas em vez de 4: com 4 o vídeo acabava no perigo e ficava sem o conserto no final.
>
> ```
> Se você é homem, você já nasceu com o caminho da hérnia pronto, bem aqui na virilha. Antes de você nascer, o testículo desceu de dentro da barriga por um túnel na parede, o canal inguinal. Esse túnel continua aí. E quando você tosse ou faz força, a pressão empurra gordura e intestino pra dentro dele. É isso que vira o caroço. E o perigo é ele entrar e não voltar: a entrada aperta e corta o sangue. Por isso a cirurgia não só empurra de volta: ela reforça a parede com uma tela.
> ```
>
> - Cena 1: 17 palavras, 7 s
> - Cena 2: 19 palavras, 8 s
> - Cena 3: 20 palavras, 8 s
> - Cena 4: 22 palavras, 9 s
> - Cena 5: 16 palavras, 7 s
> - **Total: uns 39 segundos de fala**
>
> Quer mudar alguma frase? Se estiver bom, me fala que fechou e eu monto as cenas.

Pontos de atenção: segunda pessoa ("você", "a tua barriga"), frase curta, cadeia completa (o que é, por que acontece, o perigo, o conserto), e a explicação acima do teto de tempo: se precisar de mais uma cena pra fechar a história, a skill propõe.

## 3 · Fechar as cenas

> Agora as cenas. A câmera fica parada em todas, e o que se mexe é o corpo:
>
> `01 o caminho: a parede de baixo da barriga vista em corte, com uma faixa de luz percorrendo o túnel até a virilha`
> `02 a descida: o testículo deslizando de dentro da barriga pelo túnel, deixando o caminho aberto atrás dele`
> `03 a pressão: a gordura e uma alça de intestino sendo empurradas pra dentro da entrada do túnel`
> `04 a armadilha: o anel da entrada apertando e a alça presa escurecendo, enquanto a parte que ficou dentro continua rosa`
> `05 a tela: uma tela fina deslizando sobre a entrada e tecido novo crescendo através dela`
>
> A cena 02 carrega o recado principal. A 04 é a do alerta: mostra o perigo sem precisar falar.
>
> Se estiver tudo certo, me dá o ok que eu gero o HTML.

Lição desse exemplo: o túnel em diagonal com duas aberturas e coisa viajando por dentro deixou o cenário complexo demais pro gerador. Ao escolher as cenas, preferir um cenário de camadas retas (como na hérnia abdominal, em `exemplos/hernia-abdominal.md`) e acrescentar no máximo uma estrutura especial por cena.

## 4 e 5 · Prompts e HTML

Sem mensagem intermediária: escrever os prompts seguindo `references/arquitetura-prompts.md`, montar o JSON no formato de `exemplos/hernia-inguinal.json`, rodar `python3 scripts/montar_html.py dados.json reel-[tema].html`, corrigir o que o script apontar e entregar.

Mensagem de entrega, em 2 linhas:

> Seu vídeo está pronto no arquivo reel-hernia-inguinal.html. 🎬
>
> Dentro dele tem o texto que você vai falar, as 5 cenas com os textos pra colar no Gemini, a legenda do post e as fontes científicas. É só abrir no celular ou no computador e seguir o "Como usar", que já aparece aberto no topo.

## Pedidos de ajuste depois da entrega

- "Refaz a cena 3": muda só a cena 3, mantendo SUJEITO, LOOK, VIDA e FIXA, e gera de novo o MESMO arquivo.
- "A imagem saiu diferente da cena 1": lembrar de anexar a imagem da cena 1 junto do prompt de imagem (o bloco MATCH depende disso).
- "O Gemini recusou": trocar a palavra que acionou o filtro (tabela em `references/arquitetura-prompts.md`) e, se precisar, sugerir a outra opção daquela cena.
