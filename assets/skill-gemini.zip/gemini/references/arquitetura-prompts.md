# Arquitetura dos prompts

Este arquivo explica COMO cada prompt da skill é montado e POR QUE ele é montado assim. Ler antes de escrever os prompts da etapa 4. Os textos fixos dos blocos estão no fim do SKILL.md; os exemplos completos estão em `exemplos/`.

## A ideia central

O Gemini gera cada clipe sozinho, sem lembrar do anterior. O que faz 5 clipes separados parecerem o mesmo filme é o TEXTO: as mesmas palavras descrevendo o mesmo lugar, a mesma luz e o mesmo visual em todos os prompts. Por isso o prompt é feito de BLOCOS. Alguns são escritos uma vez por vídeo e colados iguais em todas as cenas; só um pedaço muda por cena.

```
FIXO NO VÍDEO INTEIRO          MUDA EM CADA CENA           FIXO DE NOVO
[ SUJEITO ]  ->  [ ESTADO + ACROSS + MARCHA + TRAVA ]  ->  [ VIDA ] [ FIXA ] [ LOOK ]
```

## Os três prompts de cada cena

```
VÍDEO DIRETO (opção 1)
SUJEITO + ESTADO + ACROSS + MARCHA + TRAVA + VIDA + FIXA + LOOK DE VÍDEO

IMAGEM (opção 2, parte 1)
"Generate a vertical 9:16 portrait image. " + SUJEITO + ESTADO + [MATCH da cena 2 em diante] + LOOK DE IMAGEM

ANIMAR A IMAGEM (opção 2, parte 2)
"Animate this image. " + ACROSS + MARCHA + TRAVA + VIDA + FIXA
```

O vídeo direto é o mais longo porque não tem imagem: o texto precisa carregar tudo. O "animar" é o mais curto porque a imagem já carrega a aparência; repetir SUJEITO e LOOK ali faria o gerador redesenhar a cena.

## Bloco por bloco

### SUJEITO (escrito 1 vez por cenário)

**Função:** dizer O QUE é o quadro e ONDE cada coisa está, com cor e material. É o bloco que mais segura a continuidade.

**Como escrever, nesta ordem:**
1. O que o quadro é e de onde é visto ("A cross-section through a living human abdominal wall seen from the side").
2. Como as coisas se distribuem no quadro alto ("the layers running as clear horizontal bands across the whole tall frame").
3. Cada estrutura, na ordem em que aparece no quadro (de cima pra baixo ou de fora pra dentro), com cor concreta, material e brilho ("a band of deep coral red muscle with its fibres running along its length, wet and glistening").
4. Se houver algo fora do quadro, dizer pra onde ele vai ("continues past the left edge of the frame").

**Regras:**
- Uma estrutura, uma frase, uma cor. A mesma estrutura nunca muda de nome ou de cor entre cenas.
- Posição no quadro escrita literal ("at the lower right", "across the top"). Geometria de quadro sai literal do texto.
- **Cenário simples ganha.** Camadas retas, uma em cima da outra, é o desenho que o gerador acerta sempre. Túnel em diagonal, várias aberturas, coisa viajando por dentro de canal: cada uma dessas aumenta muito a chance de erro. Se o tema pede uma estrutura especial, acrescentar UMA por cena, nunca três.
- Quando a história muda de escala ou de lugar (do órgão pra célula), aquela cena ganha um SUJEITO novo.
- Termina com espaço, porque o próximo bloco é colado logo depois.

### ESTADO (muda por cena)

**Função:** dizer como o quadro está no INSTANTE em que o clipe começa, em afirmação. É aqui que a cena se diferencia das outras do mesmo cenário (íntegro, cedendo, aberto, apertado, reparado).

Exemplo: "In the middle of the frame the ivory fascia and the coral muscle beneath it are thinned and stretched over a small area, the fibres there pulled apart and strained, visibly weaker than the dense tissue on either side, though still just closed."

No prompt de IMAGEM, o ESTADO é a imagem inteira: a imagem é o primeiro quadro do clipe.

### ACROSS (muda por cena)

**Função:** resumir numa frase o evento dos 10 segundos, antes da marcha. O gerador entende o arco da cena antes dos detalhes.

Molde: "Across the ten seconds [o que acontece, do começo ao fim]." No Flow: "Across the eight seconds".

### MARCHA (muda por cena)

**Função:** dividir o evento no tempo, pra ele não acontecer todo nos 2 primeiros segundos e o resto do clipe ficar parado.

- 5 trechos de 2 segundos: "0 to 2 s: ... 2 to 4 s: ... 4 to 6 s: ... 6 to 8 s: ... 8 to 10 s: ...". No Flow, 4 trechos até 8 s.
- Cada trecho tem UMA mudança visível e concreta (a fibra puxa, a primeira fibra se solta, o vão alarga, a borda engrossa).
- O último trecho termina sempre em "and everything comes to rest".
- Comparação física simples ajuda muito: "the way a worn fabric parts under tension", "the way dough is pushed up through the neck of a jar".
- Mudança de cor é escrita como transição ("changes steadily from healthy pink to a dusky dark red"), e o que NÃO muda é dito em afirmação ("while the bowel below the ring stays bright pink and healthy").
- Movimento calmo, em velocidade real. Nunca "pulse", "pulsating" ou "throbbing": o vídeo fica pulando.

### TRAVA (muda por cena)

**Função:** dizer o que fica parado, nomeando cada estrutura. É o que impede a anatomia de "derreter" ou mudar de forma.

Molde: "The [estruturas que não mudam] hold perfectly still and keep their exact shapes, their exact thicknesses and their exact places, [estrutura que se move] keeps its own shape as it moves, and only [o que muda] moves."

### VIDA (1 vez por cenário)

**Função:** manter o fundo vivo enquanto o assunto principal age. Sem isso, o clipe parece uma foto onde só uma coisa se mexe.

Lista coisas pequenas e lentas ATRÁS do assunto: fluxo nos vasos, alça mexendo de leve, fibra balançando, gotinhas atravessando o quadro, tudo desfocado. Fora da saúde: pó fino flutuando, fio de vapor, vibração leve.

### FIXA (texto fixo)

**Função:** travar a câmera. Com a câmera parada, quem se mexe é o assunto, e o evento fica claro. Câmera andando é a causa número um de clipe que "não mostra nada".

### LOOK (1 vez por vídeo)

**Função:** o visual. Fecha todo vídeo direto (versão vídeo) e todo prompt de imagem (versão imagem). Lacunas preenchidas uma vez: o que o quadro é, três texturas, a paleta por tecido e o que precisa caber no quadro. O resto do texto é fixo e nunca é editado.

Versões:
- **Saúde e seres vivos:** o texto do SKILL.md.
- **Fora da saúde (máquina, prédio, planeta, eletrônica):** troca só os trechos indicados no SKILL.md, pra não chamar metal de tecido vivo. Exemplo completo mais abaixo.
- **Imagem:** troca a frase da câmera travada por "with clear layers of foreground, middle and far distance".

### MATCH (prompt de imagem, cena 2 em diante)

**Função:** quando a pessoa anexa a imagem da cena 1 junto do prompt, este bloco manda o gerador copiar o visual e o lugar, mudando só o estado. É o que segura a continuidade no caminho da imagem.

## Exemplo fora da saúde (freio a disco de carro)

SUJEITO:
```
A cut-away view through a car disc brake seen from the side, the parts running as clear horizontal bands across the whole tall frame. Across the top, a thick block of dark graphite-grey cast iron caliper with a satin finish. Below it, a short polished steel piston, bright and smooth, pressing down from inside the caliper. Below the piston, a brake pad: a pale silver backing plate over a thick layer of dark speckled friction material. Below the pad, the brake disc: a wide band of brushed grey iron with fine circular machining marks, running across the full width of the frame. And below the disc, a matching pad and backing plate facing upward. 
```

LOOK DE VÍDEO (versão fora da saúde, lacunas preenchidas):
```
Filmed as a hyperreal macro cutaway, extremely detailed and cinematic. THE STRUCTURE COMES FIRST AND STAYS CLEARLY READABLE: every part keeps its shape, its thickness and its boundaries, with a sharp visible edge between one material and the next, so the picture reads immediately as a cut-away of a car disc brake seen from the side. Within that structure, the surfaces carry fine texture: the circular machining marks of the disc, the speckled grain of the friction material, the satin casting of the caliper, all as surface detail rather than as the subject of the picture. EVERY MATERIAL SHOWS ITS TRUE FINISH: brushed iron, polished steel and dark friction compound, crisp and physically real. PALETTE: graphite grey in the caliper, bright steel in the piston, pale silver in the backing plates, near-black speckled grey in the friction material, brushed mid-grey in the disc, with soft neutral greys in the background. MATERIALS: every surface keeps its real finish, with crisp highlights on polished parts, fine grain and wear on matte parts, and real subsurface scattering only where the material is translucent. LIGHTING: a soft white key light from the upper left, clean and even, with gentle falloff and a delicate rim of light along every edge. BACKGROUND: a bright white clinical consulting room dissolved completely out of focus into soft white and pale grey shapes, luminous and airy, with the detail unreadable. CAMERA: cinematic macro on an 85 to 135mm lens, shallow depth of field with creamy bokeh in front and behind, positioned far enough back that the whole stack from caliper to lower pad is visible in the frame. The framing is fixed and locked off, with the same amount of the brake visible in the first frame and in the last. Physically based path traced render at extreme detail with true bokeh. Every surface is richly textured. The picture fills the whole tall vertical frame from edge to edge and is clean and free of lettering of any kind. Vertical 9:16 portrait.
```

## Escrita que passa no filtro

| Evitar | Usar |
|---|---|
| blood, bleeding | arterial red vessels, the red vessels carry a slow flow |
| wound, cut open, gore | clean field, precise linear incision |
| woman, female, man, male, silhouette | a neutral anatomical figure (o órgão indica o sexo) |
| sperm | small pale oval cells with long thin tails |
| no instruments | the field contains only the native tissue |
| pulse, pulsating, throbbing | a slow steady flow, a gentle wave travelling in one direction |

## Erros que já aconteceram e o conserto

| Sintoma | Causa provável | Conserto |
|---|---|---|
| Estrutura pequena virou uma cratera | close sem referência de tamanho | âncora de escala no SUJEITO (do tamanho de uma ponta de dedo, dezenas na densidade natural) |
| Anatomia saiu torta ou inventada | cenário com geometria demais (túnel diagonal, várias aberturas, coisa viajando) | simplificar o SUJEITO: camadas retas e no máximo uma estrutura especial por cena |
| Clipe parado, só a câmera anda | câmera livre ou evento fraco | FIXA intacto e um evento claro na marcha, com mudança em cada trecho de 2 s |
| Tudo acontece em 2 s e o resto para | sem marcha | marcha de 5 trechos cobrindo os 10 s |
| Cenas parecem de vídeos diferentes | SUJEITO ou LOOK reescrito por cena | colar os blocos por script, letra por letra |
| Apareceu algo que foi negado | negação no prompt | trocar por afirmação do que está no quadro |
| Gemini recusou | palavra que aciona filtro | tabela de escrita que passa no filtro; se insistir, a pessoa usa a outra opção (imagem ou vídeo direto) |
