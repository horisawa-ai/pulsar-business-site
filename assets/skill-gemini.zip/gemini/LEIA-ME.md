# Skill Gemini

Skill desenvolvida por Renan Horisawa | pulsar.science

Cria vídeos verticais de ciência pra gerar no Gemini (ou no Flow), do tema até um HTML pronto pra copiar e colar. Pra usar, suba o zip na área de Skills do Claude e escreva "use a skill Gemini".

## O que tem aqui dentro

- `SKILL.md`: as instruções principais da skill (fluxo, regras e os blocos fixos dos prompts).
- `references/system-prompt.md`: o contrato da skill, com o escopo, o que fica fora e as regras absolutas.
- `references/arquitetura-prompts.md`: como cada prompt é montado, bloco por bloco, e por quê.
- `references/roteiro-conversa.md`: como a conversa acontece em cada etapa, com um exemplo real.
- `exemplos/hernia-abdominal.md`: os prompts do vídeo que originou o padrão.
- `exemplos/hernia-inguinal.json` e `exemplos/hernia-inguinal.html`: os dados de entrada e a folha pronta de um vídeo completo.
- `assets/template.html`: o modelo da página.
- `scripts/montar_html.py`: monta a página e confere as regras.
